<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Webtagger - ProjetoLuixz | Criação de sites, aplicativos e software</title>
    <link rel="icon" type="image/x-icon" href="/favicon.ico">

    <!-- Fontes Roboto -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    
    <!-- css & css AOS -->
    <link rel="stylesheet" href="/css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet" />
</head>
<body>
    <header> 
        <div class="container" >
            <div class="content_header" >
                <a href="/index.html" class="div_logo" >
                    <img src="/img/logoWebtagger.png" alt="Logo WebTagger">
                    <span>webtagger</span>
                </a>
                <nav>
                    <ul>
                        <li>
                            <a href="#Home">
                                <i class="fa-solid fa-house"></i>
                                Home
                            </a>
                        </li>
                        <li>
                            <a href="#Cases">
                                <i class="fa-solid fa-briefcase"></i>
                                Cases
                            </a>
                        </li>
                        <li class="dropdown">
                            <a href="#">
                                <i class="fa-solid fa-layer-group"></i>
                                Soluções
                                <i class="fa-solid fa-chevron-down dropdown-icon"></i>
                            </a>
                            <ul class="dropdown-content">
                                <li><a href="#Sites"><i class="fa-solid fa-globe"></i> Sites</a></li>
                                <li><a href="#Aplicativos"><i class="fa-solid fa-mobile-screen-button"></i> Aplicativos</a></li>
                                <li><a href="#Sistemasemnuvem"><i class="fa-solid fa-cloud"></i> Sistemas em nuvem</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#E-commerce">
                                <i class="fa-solid fa-cart-shopping"></i>
                                E-commerce
                            </a>
                        </li>
                        <li>
                            <a href="#Hospedagem">
                                <i class="fa-solid fa-server"></i>
                                Hospedagem
                            </a>
                        </li>
                        <li>
                            <a href="#Contato">
                                <i class="fa-solid fa-envelope"></i>
                                Contato
                            </a>
                        </li>
                    </ul>
                </nav>
                
                <div class="buttons" >
                    <button class="animated-button">
                        <span>
                            Fazer orçamento
                            <i class="fa-solid fa-cart-shopping"></i>
                        </span>
                    </button>
                    <button class="menuMobile">
                        <i class="fa-solid fa-bars"></i>
                    </button>                
                </div>
            </div>
        </div>
    </header>

    <main>
        <section class="sect_Home" id="Home" >
            <div class="container">
                <div class="content_Home" >
                    <div class="content_left_Home" >
                        <h1 data-aos="fade-right" >Desenvolvemos websites, aplicativos e sistemas web que <strong>transformam</strong><br/> sua <strong>empresa</strong> </h1>
                        <p data-aos="fade-right" data-aos-delay="100" >A Webtagger traz soluções inteligentes e personalizadas de sites, aplicativos, CRMs, <br/> ERP'S e sistemas sob medida para empresas de Pouso Alegre e região.</p>
                        <div data-aos="fade-right" data-aos-delay="200" class="contet_Home_Butttons" >
                            
                            <button class="button-follow animated-button filled">
                                <span class="ball blueDark-ball"></span>
                                <span>
                                    O que fazemos
                                    <i class="fa-solid fa-circle-question"></i>
                                </span>
                            </button>
                            <button class="animated-button">
                                <span>
                                    Fazer orçamento
                                    <i class="fa-solid fa-cart-shopping"></i>
                                </span>
                            </button>
                        </div>
                    </div>
                    <div class="content_Rigth_Home" >
                        <img data-aos="fade-up" src="/img/mockups/Home.png" alt="Bradge Home">
                        <div class="cardLocal">
                            <div class="menu-top">
                                <li></li>
                                <li></li>
                                <li></li>
                            </div>
                            <div class="card-content">
                                <div class="top">
                                    <span>Local</span>
                                    <div class="cidade">
                                        <i class="fa-solid fa-location-dot"></i>
                                        <small>São Paulo</small>
                                    </div>
                                </div>
                                <div class="bottom">
                                    <h6>Hotel São Paulo</h6>
                                    <i class="fa-solid fa-check"></i>
                                </div>
                            </div>
                        </div>
                        <div class="cardReceita">
                            <div class="menu-top">
                                <li></li>
                                <li></li>
                                <li></li>
                            </div>
                            <div class="card-content">
                                <div class="texts">
                                    <span>RECEITA</span>
                                    <h6 id="valorReceita" >R$4.820,00</h6>
                                    <ul>
                                        <li class="active" >Dia</li>
                                        <li>Mês</li>
                                        <li>Ano</li>
                                    </ul>
                                </div>
                                <div class="map">
                                    <img src="/img/mockups/map.png" alt="Local Mapa">
                                </div>
                            </div>
                        </div>
                        <div class="cardTimer">
                            <div class="menu-top">
                                <li></li>
                                <li></li>
                                <li></li>
                            </div>
                            <div class="card-content">
                                <span>
                                    <i class="fa-solid fa-bolt"></i>
                                    CARREGAMENTO
                                </span>
                            
                                <!-- Barra de progresso -->
                                <div class="progress-wrap">
                                    <div class="progress-bar"></div>
                                </div>
                            
                                <!-- Status que muda ao final -->
                                <h6 id="statusCarga">
                                    <i class="fa-solid fa-spinner fa-spin"></i>
                                    Carregando...
                                </h6>
                                <i id="reloadBtn" class="fa-solid fa-rotate-right reload-btn" title="Recarregar"></i>

                            </div>
                        </div>
                        <div class="cardVisits">
                            <div class="menu-top">
                                <li></li>
                                <li></li>
                                <li></li>
                            </div>
                            <div class="card-content">
                                <span>
                                    <i class="fa-solid fa-users"></i>
                                    Visitas
                                </span>
                                <h6 id="valorVisitas">342</h6>
                                <ul>
                                    <li class="active">Dia</li>
                                    <li>Mês</li>
                                    <li>Ano</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    
        <section class="sect_Numbers">
            <div class="container">
                <ul class="stats-list">
                    <li data-aos="zoom-in-up" data-aos-delay="100" class="stat-item">
                        <div class="stat-icon">
                        <i class="fa-solid fa-calendar-check"></i>
                        </div>
                        <h4 class="stat-value">
                        <span>18+</span> anos de experiência
                        </h4>
                        <p class="stat-text">Entregando resultados consistentes desde 2007</p>
                    </li>
                    <li data-aos="zoom-in-up" class="stat-item">
                        <div class="stat-icon">
                        <i class="fa-solid fa-users"></i>
                        </div>
                        <h4 class="stat-value">
                        <span>500.000</span> usuários diários
                        </h4>
                        <p class="stat-text">Confiando nas nossas soluções todos os dias</p>
                    </li>
                    <li data-aos="zoom-in-up" data-aos-delay="100" class="stat-item">
                        <div class="stat-icon">
                        <i class="fa-solid fa-building"></i>
                        </div>
                        <h4 class="stat-value">
                        <span>600+</span> empresas atendidas
                        </h4>
                        <p class="stat-text">Parceiras de diversos segmentos e portes</p>
                    </li>
                </ul>
            </div>
        </section>
    
        <section id="Cases" class="sect_Cases" >
            <div class="container">
                <div class="case_1">
                  <span data-aos="fade-down" data-aos-delay="100" >PROJETOS</span>
                  <h2 data-aos="fade-down" >Cases de Sucesso</h2>
                </div>
            </div>
          
            <swiper-container data-aos="fade-up" data-aos-duration="2000" id="meuSwiper" class=" mySwiper" pagination="true" pagination-clickable="true" navigation="true" space-between="30" slides-per-view="3"
              centered-slides="true" autoplay-delay="3500" autoplay-disable-on-interaction="true" loop="true" effect="coverflow" coverflow-effect-slide-shadows="false">
          
                <swiper-slide>
                    <div class="case_item">
                        <h3>EAG Empresa Autogerenciável</h3>
                        <div class="case_content" >
                            <img class="case_desktop" src="https://webtagger.com.br/wp-content/themes/SiteWebtaggerWp/assets/img/mockups/EAGDesktop.webp" alt="Projeto Natureza 1" />
                            <img class="case_mobile" src="https://webtagger.com.br/wp-content/themes/SiteWebtaggerWp/assets/img/mockups/EAGMobile.webp" alt="">
                        </div>
                    </div>
                </swiper-slide>
                <swiper-slide>
                    <div class="case_item">
                        <h3>AIFLA Construtora</h3>
                        <div class="case_content" >
                            <img class="case_desktop" src="https://webtagger.com.br/wp-content/themes/SiteWebtaggerWp/assets/img/mockups/AIFLAConstrutoraDesktop.webp" alt="Projeto Natureza 1" />
                            <img class="case_mobile" src="https://webtagger.com.br/wp-content/themes/SiteWebtaggerWp/assets/img/mockups/AIFLAConstrutoraMobile.webp" alt="">
                        </div>
                    </div>
                </swiper-slide>
                <swiper-slide>
                    <div class="case_item">
                        <h3>GEOMAT Distribuidora</h3>
                        <div class="case_content" >
                            <img class="case_desktop" src="https://webtagger.com.br/wp-content/themes/SiteWebtaggerWp/assets/img/mockups/geomatDesktop.webp" alt="Projeto Natureza 1" />
                            <img class="case_mobile" src="https://webtagger.com.br/wp-content/themes/SiteWebtaggerWp/assets/img/mockups/geomatMobile.webp" alt="">
                        </div>
                    </div>
                </swiper-slide>
                <swiper-slide>
                    <div class="case_item">
                        <h3>OncoLavras</h3>
                        <div class="case_content" >
                            <img class="case_desktop" src="https://webtagger.com.br/wp-content/themes/SiteWebtaggerWp/assets/img/mockups/OncolavrasDesk.webp" alt="Projeto Natureza 1" />
                            <img class="case_mobile" src="https://webtagger.com.br/wp-content/themes/SiteWebtaggerWp/assets/img/mockups/OncolavrasMob.webp" alt="">
                        </div>
                    </div>
                </swiper-slide>
                <swiper-slide>
                    <div class="case_item">
                        <h3>Seul Cosméticos</h3>
                        <div class="case_content" >
                            <img class="case_desktop" src="https://webtagger.com.br/wp-content/themes/SiteWebtaggerWp/assets/img/mockups/seulDesktop.webp" alt="Projeto Natureza 1" />
                            <img class="case_mobile" src="https://webtagger.com.br/wp-content/themes/SiteWebtaggerWp/assets/img/mockups/seulMobile.webp" alt="">
                        </div>
                    </div>
                </swiper-slide>
                <swiper-slide>
                    <div class="case_item">
                        <h3>Cacife Tintas</h3>
                        <div class="case_content" >
                            <img class="case_desktop" src="https://webtagger.com.br/wp-content/themes/SiteWebtaggerWp/assets/img/mockups/cacifeDesktop.webp" alt="Projeto Natureza 1" />
                            <img class="case_mobile" src="https://webtagger.com.br/wp-content/themes/SiteWebtaggerWp/assets/img/mockups/cacifeMobile.webp" alt="">
                        </div>
                    </div>
                </swiper-slide>
                <swiper-slide>
                    <div class="case_item">
                        <h3>Hud Sports</h3>
                        <div class="case_content" >
                            <img class="case_desktop" src="https://webtagger.com.br/wp-content/themes/SiteWebtaggerWp/assets/img/mockups/hubDesktop.webp" alt="Projeto Natureza 1" />
                            <img class="case_mobile" src="https://webtagger.com.br/wp-content/themes/SiteWebtaggerWp/assets/img/mockups/hubMobile.webp" alt="">
                        </div>
                    </div>
                </swiper-slide>
            </swiper-container>
        </section>
          
        <section data-aos="fade-up" id="Sites" class="sect_Sites" >
            <div class="container">
                <div class="content">
                    <div data-aos="zoom-in" data-aos-delay="200" class="left box" >
                        <img class="mk1" src="/img/mockups/sites-1.png" alt="Mockups de Site">
                        <img class="mk2" src="/img/mockups/sites-2.png" alt="Mockups de Site">
                        <img class="mk3" src="/img/mockups/sites-3.png" alt="Mockups de Site">
                        <img class="mk4" src="/img/mockups/sites-4.svg" alt="Mockups de Site">
                    </div>
                    <div data-aos="fade-up" data-aos-delay="400" class="rigth" >
                        <img data-aos="flip-down" src="/img/icons/site-web.png" alt="">
                        <h2 data-aos="fade-down" data-aos-delay="600">Sites</h2>
                        <p data-aos="fade-up" data-aos-delay="400" >Aumente o sucesso do seu negócio com a webtagger!</p>
                        <p data-aos="fade-up" data-aos-delay="500">Conte com os serviços especializados da webtagger para criar sites e sistemas web personalizados. Nossa equipe experiente está pronta para desenvolver projetos únicos, gerando resultados tangíveis e impulsionando as conversões em vendas.</p>
                        <p data-aos="fade-up" data-aos-delay="600">Graças à nossa expertise em design e desenvolvimento, podemos criar sites modernos e profissionais que refletem a identidade da sua marca. Além disso, nossos sistemas web são feitos sob medida para aprimorar a comunicação e a eficiência da sua organização.</p>
                        <p data-aos="fade-up" data-aos-delay="700">Não deixe seu negócio ficar para trás. Confie na webtagger para criar projetos exclusivos que geram mais resultados e conversões em vendas.</p>
                        <button  data-aos="zoom-in" data-aos-delay="900" class="button-follow btn-green" >
                            <span class="ball green-ball"></span>
                            Fazer orçamento
                            <i class="fa-solid fa-cart-shopping"></i>
                        </button>
                    </div>
                </div>
            </div>
        </section>
    
        <section data-aos="fade-up" id="Aplicativos" class="sect_Aplicativos" >
            <div class="container">
                <div class="content">
                    <div data-aos="fade-right" class="left">
                        <img data-aos="flip-left" src="/img/icons/aplicativo-yellow.png" alt="Icon Aplicativo">
                        <h2 data-aos="fade-down" data-aos-delay="200">Aplicativos</h2>
                        <p data-aos="fade-up" data-aos-delay="600">Impulsione o crescimento do seu negócio com um aplicativo sob medida!</p>
                        <p data-aos="fade-up" data-aos-delay="700">Invista no sucesso da sua startup ou empresa de médio e grande porte com os serviços especializados de criação de aplicativos oferecidos por nós. Nosso processo abrange um planejamento estrutural detalhado, desenvolvimento em etapas e suporte técnico contínuo. Além disso, estamos comprometidos em manter a sua ferramenta sempre atualizada e competitiva. Não perca tempo, impulsione o seu sucesso com um aplicativo personalizado.</p>
                        <button data-aos="zoom-in" data-aos-delay="500" class="button-follow btn-yellow" >
                            <span class="ball yellow-ball"></span>
                            Fazer orçamento
                            <i class="fa-solid fa-cart-shopping"></i>
                        </button>
                    </div>
                    <div data-aos="zoom-in" data-aos-delay="400" class="rigth box">
                        <img class="mk1" src="/img/mockups/aplicativos-1.png" alt="Mockups de Aplicativos">
                        <img class="mk2" src="/img/mockups/aplicativos-2.png" alt="Mockups de Aplicativos">
                        <img class="mk3" src="/img/mockups/aplicativos-3.png" alt="Mockups de Aplicativos">
                        <img class="mk4" src="/img/mockups/aplicativos-4.png" alt="Mockups de Aplicativos">
                    </div>
                </div>
            </div>
        </section>
    
        <section data-aos="fade-up" id="Sistemasemnuvem" class="sect_Sistemasemnuvem">
            <div class="container">
                <div class="content">
                    <div class="left box" data-aos="zoom-in" data-aos-delay="200">
                        <img class="mk1" src="/img/mockups/sistema-nuvem-1.png" alt="Mockups de Sistema na nuvem">
                        <img class="mk2" src="/img/mockups/sistema-nuvem-2.png" alt="Mockups de Sistema na nuvem">
                        <img class="mk3" src="/img/mockups/sistema-nuvem-3.png" alt="Mockups de Sistema na nuvem">
                        <img class="mk4" src="/img/mockups/sistema-nuvem-4.png" alt="Mockups de Sistema na nuvem">
                    </div>
                    <div data-aos="fade-up" data-aos-delay="400" class="rigth">
                        <img data-aos="flip-down" src="/img/icons/nuvem-blue.png" alt="Icon Nuvem">
                        <h2 data-aos="fade-down" data-aos-delay="600" >Sistemas em nuvem</h2>
                        <p data-aos="fade-up" data-aos-delay="400" >Expanda seus negócios com soluções em nuvem!</p>
                        <p data-aos="fade-up" data-aos-delay="500">Conte conosco para desenvolver projetos sob medida, integrar sistemas, implementar infraestrutura de servidor e fornecer suporte especializado. Nossa equipe atende médias e grandes empresas, oferecendo serviços de alta qualidade para impulsionar a eficiência e o sucesso dos seus negócios. Com a ajuda dos nossos especialistas experientes, você terá projetos personalizados, integração eficiente de sistemas, configuração adequada de infraestrutura de servidor e suporte técnico especializado, garantindo que você tenha todas as ferramentas necessárias para um crescimento contínuo.</p>
                        <p data-aos="fade-up" data-aos-delay="700">Não perca tempo, invista em soluções personalizadas que atendam às suas necessidades.</p>
                        <button data-aos="zoom-in" data-aos-delay="900" class="button-follow btn-blue" >
                            <span class="ball blue-ball"></span>
                            Fazer orçamento
                            <i class="fa-solid fa-cart-shopping"></i>
                        </button>
                    </div>
                </div>
            </div>
        </section>
    
        <section data-aos="fade-up" id="E-commerce" class="sect_E-commerce" data-aos="fade-up">
            <div class="container">
                <div class="content">
                    <div class="left" data-aos="fade-right">
                        <img data-aos="flip-left" src="/img/icons/e-commerce-red.png" alt="Icon E-commerce">
                        <h2 data-aos="fade-down" data-aos-delay="200">E-commerce</h2>
                        <p data-aos="fade-up" data-aos-delay="400">Potencialize suas vendas com um e-commerce eficiente e lucrativo!</p>
                        <p data-aos="fade-up" data-aos-delay="300">Nosso time especializado oferece soluções personalizadas para impulsionar o crescimento do seu negócio online.</p>
                        <p data-aos="fade-up" data-aos-delay="200">Desenvolvemos uma plataforma exclusiva, adaptada às suas necessidades, que proporciona uma experiência de compra fácil e intuitiva para seus clientes.</p>
                        <p data-aos="fade-up" data-aos-delay="100">Além disso, realizamos integrações entre sistemas, garantindo uma gestão eficiente do estoque, processamento de pagamentos e logística. Nossa infraestrutura de servidor robusta assegura a estabilidade e segurança da sua loja virtual.</p>
                        <button data-aos="zoom-in" data-aos-delay="500" class="button-follow btn-red" >
                            <span class="ball red-ball"></span>
                            Fazer orçamento
                            <i class="fa-solid fa-cart-shopping"></i>
                        </button>
                    </div>
                    <div data-aos="zoom-in" data-aos-delay="400" class="rigth box">
                        <img class="mk1" src="/img/mockups/e-commerce-1.png" alt="Mockups de E-commerce">
                        <img class="mk2" src="/img/mockups/e-commerce-2.png" alt="Mockups de E-commerce">
                        <img class="mk3" src="/img/mockups/e-commerce-3.png" alt="Mockups de E-commerce">
                        <img class="mk4" src="/img/mockups/e-commerce-4.png" alt="Mockups de E-commerce">
                    </div>
                </div>
            </div>
        </section>
    
        <section data-aos="fade-up" id="Hospedagem" class="sect_Hospedagem" >
            <div class="container">
                <div class="content">
                    <div data-aos="zoom-in" data-aos-delay="200" class="left box">
                        <img class="mk1" src="/img/mockups/hosp-1.png" alt="Mockups da Hospedagem">
                        <img class="mk2" src="/img/mockups/hosp-2.png" alt="Mockups da Hospedagem">
                        <img class="mk3" src="/img/mockups/hosp-3.png" alt="Mockups da Hospedagem">
                        <img class="mk4" src="/img/mockups/hosp-4.png" alt="Mockups da Hospedagem">
                    </div>
                    <div  data-aos="fade-up" data-aos-delay="400" class="rigth">
                        <img data-aos="flip-down" src="/img/icons/hospedagem-cinza.png" alt="">
                        <h2 data-aos="fade-down" data-aos-delay="600">Hospedagem</h2>
                        <p data-aos="fade-up" data-aos-delay="400">Tenha uma hospedagem confiável e de alto desempenho para o seu site!</p>
                        <p data-aos="fade-up" data-aos-delay="500">Tenha soluções de hospedagem adaptadas às necessidades da sua empresa de médio e grande porte. Nossa equipe garante um serviço de qualidade, com uma infraestrutura de servidor robusta que garante alta disponibilidade e velocidade para o seu site.</p>
                        <p data-aos="fade-up" data-aos-delay="600">Com nossos serviços de hospedagem, você pode ter a tranquilidade de saber que o seu site estará sempre online, proporcionando uma experiência superior aos visitantes.</p>
                        <p data-aos="fade-up" data-aos-delay="700">Não deixe sua presença online comprometida, invista em uma hospedagem confiável e de alto desempenho.</p>
                        <button data-aos="zoom-in" data-aos-delay="900" class="animated-button">
                            <span>
                                Fazer orçamento
                                <i class="fa-solid fa-cart-shopping"></i>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
        </section>
        
        <section class="sect_Tecnolog">
            <div class="content-infos">
                <h2 data-aos="fade-up" ><strong>Trabalhamos com as</strong> mais novas tecnologias</h2>
                <p data-aos="fade-up" data-aos-delay="100">Temos planos mensais que cabem no seu bolso. Faça um orçamento:</p>
                <button data-aos="zoom-in" data-aos-delay="200" class="animated-button">
                    <span>Fazer orçamento <i class="fa-solid fa-cart-shopping"></i></span>
                </button>
            </div>
            
            <div class="content-icons-absolute">
                <div class="content-icons">
                <!-- Cada tech-item mantém a posição absoluta original -->
                <div class="tech-item img-1" data-code="httpd -k restart" data-lang="Apache">
                    <img src="/img/icons/apache.svg" alt="Apache" />
                    <div class="tooltip"><code></code></div>
                </div>
                <div class="tech-item img-2" data-code="docker run hello-world" data-lang="Docker">
                    <img src="/img/icons/docker.svg" alt="Docker" />
                    <div class="tooltip"><code></code></div>
                </div>
                <div class="tech-item img-3" data-code="console.log('Olá Mundo');" data-lang="JavaScript">
                    <img src="/img/icons/javascript.svg" alt="JavaScript" />
                    <div class="tooltip"><code></code></div>
                </div>
                <div class="tech-item img-4" data-code="php artisan serve" data-lang="Laravel">
                    <img src="/img/icons/laravel.svg" alt="Laravel" />
                    <div class="tooltip"><code></code></div>
                </div>
                <div class="tech-item img-5" data-code="ls -la" data-lang="Linux">
                    <img src="/img/icons/linux.png" alt="Linux" />
                    <div class="tooltip"><code></code></div>
                </div>
                <div class="tech-item img-6" data-code="node hello_world.js" data-lang="Node.js">
                    <img src="/img/icons/node.svg" alt="Node.js" />
                    <div class="tooltip"><code></code></div>
                </div>
                <div class="tech-item img-7" data-code='?php echo "Olá Mundo PHP!"; ' data-lang="PHP">
                    <img src="/img/icons/php.svg" alt="PHP" />
                    <div class="tooltip"><code></code></div>
                </div>
                <div class="tech-item img-8" data-code='print(\"Olá Swift\")' data-lang="Swift">
                    <img src="/img/icons/siwft.png" alt="Swift" />
                    <div class="tooltip"><code></code></div>
                </div>
                <div class="tech-item img-9" data-code="wp plugin list" data-lang="WordPress">
                    <img src="/img/icons/wp.svg" alt="WordPress" />
                    <div class="tooltip"><code></code></div>
                </div>
                </div>
            </div>
        </section>
    
        <section class="empresas">
            <div class="container">
                <h2 class="titulo">Empresas que confiam em nós</h2>
                <div class="grade-logos">
                <div class="logo-item">
                    <img src="/img/brand/newAlba.svg" alt="Alba" />
                    <div class="nome-empresa">Alba</div>
                </div>
                <div class="logo-item">
                    <img src="/img/brand/newBetonlab.svg" alt="Betonlab" />
                    <div class="nome-empresa">Betonlab</div>
                </div>
                <div class="logo-item">
                    <img src="/img/brand/newCacife.svg" alt="Cacife" />
                    <div class="nome-empresa">Cacife</div>
                </div>
                <div class="logo-item">
                    <img src="/img/brand/newCambc.svg" alt="Cambc" />
                    <div class="nome-empresa">Cambc</div>
                </div>
                <div class="logo-item">
                    <img src="/img/brand/newDigital.svg" alt="Digital" />
                    <div class="nome-empresa">Digital</div>
                </div>
                <div class="logo-item">
                    <img src="/img/brand/newFaculdade.svg" alt="Faculdade" />
                    <div class="nome-empresa">Faculdade</div>
                </div>
                <div class="logo-item">
                    <img src="/img/brand/newFilterBras.svg" alt="FilterBras" />
                    <div class="nome-empresa">FilterBras</div>
                </div>
                <div class="logo-item">
                    <img src="/img/brand/newFonseca.svg" alt="Fonseca" />
                    <div class="nome-empresa">Fonseca</div>
                </div>
                <div class="logo-item">
                    <img src="/img/brand/newFrisul.svg" alt="Frisul" />
                    <div class="nome-empresa">Frisul</div>
                </div>
                <div class="logo-item">
                    <img src="/img/brand/newIbn.svg" alt="Ibn" />
                    <div class="nome-empresa">Ibn</div>
                </div>
                <div class="logo-item">
                    <img src="/img/brand/newJbl.svg" alt="Jbl" />
                    <div class="nome-empresa">Jbl</div>
                </div>
                <div class="logo-item">
                    <img src="/img/brand/newMcm.svg" alt="Mcm" />
                    <div class="nome-empresa">Mcm</div>
                </div>
                <div class="logo-item">
                    <img src="/img/brand/newMiranda.svg" alt="Miranda" />
                    <div class="nome-empresa">Miranda</div>
                </div>
                <div class="logo-item">
                    <img src="/img/brand/newNannetti.svg" alt="Nannetti" />
                    <div class="nome-empresa">Nannetti</div>
                </div>
                <div class="logo-item">
                    <img src="/img/brand/newNitida.svg" alt="Nitida" />
                    <div class="nome-empresa">Nitida</div>
                </div>
                <div class="logo-item">
                    <img src="/img/brand/newNovaMinas.svg" alt="NovaMinas" />
                    <div class="nome-empresa">NovaMinas</div>
                </div>
                <div class="logo-item">
                    <img src="/img/brand/newOctoBrazil.svg" alt="OctoBrazil" />
                    <div class="nome-empresa">OctoBrazil</div>
                </div>
                <div class="logo-item">
                    <img src="/img/brand/newOncominas.svg" alt="Oncominas" />
                    <div class="nome-empresa">Oncominas</div>
                </div>
                <div class="logo-item">
                    <img src="/img/brand/newSchulzCampos.svg" alt="SchulzCampos" />
                    <div class="nome-empresa">SchulzCampos</div>
                </div>
                <div class="logo-item">
                    <img src="/img/brand/newSeltec.svg" alt="Seltec" />
                    <div class="nome-empresa">Seltec</div>
                </div>
                <div class="logo-item">
                    <img src="/img/brand/newSeul.svg" alt="Seul" />
                    <div class="nome-empresa">Seul</div>
                </div>
                <div class="logo-item">
                    <img src="/img/brand/newSeuResultado.svg" alt="SeuResultado" />
                    <div class="nome-empresa">SeuResultado</div>
                </div>
                <div class="logo-item">
                    <img src="/img/brand/newSoliton.svg" alt="Soliton" />
                    <div class="nome-empresa">Soliton</div>
                </div>
                <div class="logo-item">
                    <img src="/img/brand/newSolled.svg" alt="Solled" />
                    <div class="nome-empresa">Solled</div>
                </div>
                <div class="logo-item">
                    <img src="/img/brand/newTmt.svg" alt="Tmt" />
                    <div class="nome-empresa">Tmt</div>
                </div>
                <div class="logo-item">
                    <img src="/img/brand/newTropicalFood.svg" alt="TropicalFood" />
                    <div class="nome-empresa">TropicalFood</div>
                </div>
                </div>
            </div>
        </section>

        <section class="avaliacoes">
            <div class="container">
                <h2 data-aos="fade-up" class="titulo">Avaliações dos nossos clientes</h2>
            
                <div class="cards">
                    <!-- Avaliação 1 -->
                    <div data-aos="fade-right" data-aos-delay="100" class="card">
                        <div class="perfil">
                        <div class="avatar avatar-red">A</div>
                        <div class="info">
                            <p class="nome">Ahlex Van der All</p>
                            <p class="tempo">3 meses atrás</p>
                        </div>
                        </div>
                        <div class="estrelas">★★★★★</div>
                        <p class="comentario">Hospedo meus site e emails com eles.</p>
                    </div>
                
                    <!-- Avaliação 2 -->
                    <div data-aos="fade-right" data-aos-delay="200" class="card">
                        <div class="perfil">
                        <div class="avatar avatar-verde">G</div>
                        <div class="info">
                            <p class="nome">Giovane Ricardo <span>(Auto Socorro jacaré 381)</span></p>
                            <p class="tempo">7 meses atrás</p>
                        </div>
                        </div>
                        <div class="estrelas">★★★★★</div>
                        <p class="comentario">Fiz meu site com eles.</p>
                    </div>
                
                    <!-- Avaliação 3 -->
                    <div data-aos="fade-right" data-aos-delay="300" class="card">
                        <div class="perfil">
                        <div class="avatar avatar-marrom">S</div>
                        <div class="info">
                            <p class="nome">Saulo Andrade Araújo</p>
                            <p class="tempo">5 anos atrás</p>
                        </div>
                        </div>
                        <div class="estrelas">★★★★★</div>
                        <p class="comentario">Excelente serviço. Ficou muito bonito nosso site.</p>
                    </div>
                </div>
            </div>
        </section>

        <section class="cta">
            <img data-aos="zoom-in" data-aos-delay="100" class="brandAnos" src="/img/BrandAnos.png" alt="BrandAnos">
            <div  data-aos="fade-up" class="cta-content">
                <h2 class="cta-title">Leve seu negócio para o digital com a WebTagger</h2>
                <p class="cta-subtitle">Sites rápidos, bonitos e prontos para converter. Solicite seu orçamento sem compromisso.</p>
                <button data-aos="zoom-in-up" data-aos-delay="300" class="animated-button">
                    <span>
                        Fazer orçamento
                        <i class="fa-solid fa-cart-shopping"></i>
                    </span>
                </button>
            </div>
        </section>
    
        <footer id="Contato" class="site-footer">
            <div class="footer-top container">
                <div class="footer-brand">
                    <!-- Substitua pelo seu logo -->
                    <a href="/index.html" class="div_logo">
                        <img src="/img/logoWebtagger.png" alt="Logo WebTagger">
                        <span>webtagger</span>
                    </a>
                    <p>Por mais de 18 anos a Webtagger é sinônimo de competência e inovação em desenvolvimento web em Pouso Alegre.</p>
                </div>
        
                <nav class="footer-nav">
                    <h6>Navegue</h6>
                    <div class="nav-columns">
                        <ul>
                            <li>
                                <a href="#Home">
                                    <i class="fa-solid fa-house"></i>
                                    Home
                                </a>
                            </li>
                            <li>
                                <a href="#Cases">
                                    <i class="fa-solid fa-briefcase"></i>
                                    Cases
                                </a>
                            </li>
                            <li>
                                <a href="#Sites">
                                    <i class="fa-solid fa-globe"></i>
                                    Sites
                                </a>
                            </li>
                            <li>
                                <a href="#Aplicativos">
                                    <i class="fa-solid fa-mobile-screen-button"></i>
                                    Aplicativos
                                </a>
                            </li>
                        </ul>
                        <ul>
                            <li>
                                <a href="#Sistemasemnuvem">
                                    <i class="fa-solid fa-cloud"></i>
                                    Sistemas em nuvem
                                </a>
                            </li>
                            <li>
                                <a href="#E-commerce">
                                    <i class="fa-solid fa-cart-shopping"></i>
                                    E-commerce
                                </a>
                            </li>
                            <li>
                                <a href="#Hospedagem">
                                    <i class="fa-solid fa-server"></i>
                                    Hospedagem
                                </a>
                            </li>
                            <li>
                                <a href="#Contato">
                                    <i class="fa-solid fa-envelope"></i>
                                    Contato
                                </a>
                            </li>
                        </ul>
                    </div>
                </nav>
        
                <div class="footer-location">
                    <h6>Onde estamos</h6>
                    <p>Pouso Alegre, Centro – MG, Brasil</p>
                    <p>R. Afonso Pena, 245 – ap 201 </p>
                    <p>37550-000</p>
                </div>
        
                <div class="footer-contact">
                    <h6>Siga nas redes</h6>
                    <div class="socials">
                        <a href="https://instagram.com/webtagger" class="icon-instagram" target="_blank">
                            <i class="fab fa-instagram"></i> @webtagger
                        </a>
                    </div>
        
                    <h6>Fale conosco</h6>
                    <p>
                        <a href="mailto:atendimento@webtagger.com.br" class="icon-mail">
                            <i class="fa-solid fa-envelope"></i> atendimento@webtagger.com.br
                        </a><br/>
                        <a href="tel:+5535998587371" class="icon-phone">
                            <i class="fa-solid fa-phone"></i> +55 (35) 99858-7371
                        </a>
                    </p>
                </div>
            </div>
        
            <div class="footer-bottom container">
                <small>© 2025 WebTagger. Projeto fictício criado para fins de estudo e demonstração de habilidades em desenvolvimento web.</small>
                <div class="dev">
                    <small>Desenvolvido por: </small>
                    <a href="https://luixzsouza.com.br" target="_blank"><img src="/img/luizsouza-developer.png" alt="Logo do desenvolvedor"></a>
                </div>
            </div>
        </footer>
    </main>

    <div class="menu-overlay"></div>
    <div class="mobile-menu">
        <div>
            <div class="content-top-menu" >
                <a href="/index.html" class="div_logo" >
                    <img src="/img/logoWebtagger.png" alt="Logo WebTagger">
                    <span>webtagger</span>
                </a>
                <button class="close-menu"><i class="fa-solid fa-xmark"></i></button>
            </div>
            <nav>
                <ul>
                    <li>
                        <a href="#">
                            <i class="fa-solid fa-house"></i>
                            Home
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="fa-solid fa-briefcase"></i>
                            Cases
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="fa-solid fa-globe"></i>
                            Sites
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="fa-solid fa-mobile-screen-button"></i>
                            Aplicativos
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="fa-solid fa-cloud"></i>
                            Sistemas em nuvem
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="fa-solid fa-cart-shopping"></i>
                            E-commerce
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="fa-solid fa-server"></i>
                            Hospedagem
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="fa-solid fa-envelope"></i>
                            Contato
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
        <button class="animated-button">
            <span>
                Fazer orçamento
                <i class="fa-solid fa-cart-shopping"></i>
            </span>
        </button>
    </div>

    <a class="whatsapp-button" href="https://wa.me/SEUNUMERO" target="_blank" aria-label="Fale conosco pelo WhatsApp">
        <i class="fab fa-whatsapp whatsapp-icon"></i>
        <i class="fas fa-bell call-bell">
            <span class="whatsapp-ping"></span>
        </i>
        <span>Solicite um Orçamento!</span>
    </a>    

    <!-- Script AOS Animations -->
    <script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
      
    <!-- Script Slide -->
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-element-bundle.min.js"></script>

    <!-- Icone do FontAwesome -->
    <script src="https://kit.fontawesome.com/ed4d698bbc.js" crossorigin="anonymous"></script>
    
    <!-- Meu Script -->
    <script src="/js/script.js" ></script>
</body>
</html>

